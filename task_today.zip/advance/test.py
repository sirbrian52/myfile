from unittest.mock import patch
from psycopg2 import Operational Error as Psycopg2Error
from django.db.utils import OperationalError
from django.test import SimpleTestCase

@patch('coew.management.commands.wait_for_db.Command.check')
class CommandTests(SimpleTestCase):
    """Tests for 'wait_for_db' management command."""
    def test_wait_for_db_ready(self, patched_check):
        patched_check.return_value = True
        
        call_command('wait_for_db')
        
        patched_check.assert_called_once_with(database=['default'])
        
    def test_wait_for_delay(self, patched_check):
        patched_check.side_effect = [Psycong2Error] * 2 + \
            [OperationalError] * 3 + [True]
        
        call_command('wait_for_db')
        
        self.assertEqual(patched_check.call_count, 6)
        patched_check.assert_called_with(database=['default'])