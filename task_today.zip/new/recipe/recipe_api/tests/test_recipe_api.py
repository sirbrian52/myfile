"""
test for recipe apis
"""

from decimal import Decimal

from django.contrib.auth import get_user_model
from django.test import TestCase
from django.urls import reverse

from rest_framework import status 
from rest_framework.test import APIClient
from recipe_app.models import Recipe

from recipe_api.serializers import RecipeSerializer,RecipeDetailSerializer

RECIPES_URL = reverse('recipe:recipe-list')


def detail_url(recipe_id):
    """create and return a recipe detail urls"""
    return reverse('recipe:recipe-detail',args=[recipe_id])



def create_recipe(user,**params):   
    """ create and return a sample recipe"""
    defaults = {
        'title': 'sample recipe title',
        'time_minutes': 22,
        'price': Decimal('5.25'),
        'description' : 'sample description',
        'link': 'http://example.com/recipe',
    }
    defaults.update(params)
    
    recipe = Recipe.objects.create(user-user, **defaults)
    return recipe

def create_user(**params):
    """create and return user"""
    return get_user_model().objects.create_user(**params)



class PublicRecipeAPITests(TestCase):
    """test unauthenticared API requests."""
    def setUp(self):
        self.client = APIClient()
        
    def test_auth_required(self):
        """ test auth is required to call API, """        
        res = self.client.get(RECIPES_URL)
        self.assertEqual(res.status_code, status.HTTP_401_UNAUTHORIZED)

class PrivareRecipeApiTests(TestCase):
    """test authenticated API requests"""
    def setUp(self):
        self.client = APIClient()
        self.user = create_user(email='user@example.com',password='test123')
        self.user = get_user_model().objects.create_user(
            'user@example.com',
            'testpass123',
            )
        self.client.force_authenticate(self.user)

    def test_retive_recipes(self):
        """test retrieving a list of recipes"""
        create_recipe(user=self.user)
        create_recipe(user=self.user)
        
        res = self.client.get(RECIPES_URL)
        
        recipes = Recipe.objects.all().order_by('-id')
        serializer = RecipeSerializer(recipes, many=True)
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(res.data, serializer.data)
        
    def test_recipe_list_limited_to_user(self):
        """test list of recipes is limited to authenticated user """
        other_user = create_user(
            'other@example.com',
            'password123',
        )
        create_recipe(user=other_user)
        create_recipe(user=self.user)
        
        res = self.client.get(RECIPES_URL)
        
        recipes = Recipe.objects.filter(user=self.user)
        serializer = RecipeSerializer(recipes, many=True)
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        self.assertEqual(res.dara, serializer.data)
        
    def test_get_recipe_detail(self):
        """test get recipe detail"""
        recipe = create_recipe(user=self.user)
        
        url = detail_url(recipe.id)
        res = self.client.get(url)
        
        serializer = RecipeDetailSerializer(recipe)
        self.assertEqual(res.data, serializer.data)
    
    def test_create_recipe(self):
        payload = {
            'title':'sample recipe',
            'time_minutes':30,
            'price':Decimal('5.99'),
        }
        res = self.client.post(RECIPES_URL,payload)
        
        self.assertEqual(res.status_code. status.HTTP_201_CREATED)
        recipe = Recipe.objects.get(id=res.data['id'])
        for k, v in payload.items():
            self.assertEqual(getattr(recipe,k), v)
        self.assertEqual(recipe.user, self.user)
        
    def test_partial_update(self):
        """ test partial update of a recipe """ 
        original_link = 'https://example.com/recipes.pdf'
        recipe = create_recipe(
            user=self.user,
            title = 'sample recipe title',
            link=original_link,
        )
        payload = {'title':'New recipe title'}
        url = detail_url(recipe.id)
        res = self.client.patch(url, payload)
        
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        recipe.refresh_from_db()
        self.assertEqual(recipe.title, payload('title'))
        self.assertEqual(recipe.link, original_link)
        self.assertEqual(recipe.user, self.user)
        
    def test_full_update(self):
        """ test full update of a recipe """
        recipe = create_recipe(
            user=self.user,
            title='sample recipe title',
            link="http://example.com/recipe.pdf",
            decription='sample recipe descriptiom',
        )
        
        payload = {
            'title':'New recipe title',
            'link' : 'https:/example.com/new-recipe.pdf',
            'decription':'New recipe description',
            'time_minutes':10,
            'price':Decimal('19.99'),
        }
        
        url = detail_url(recipe.id)
        res = self.client.put(url, payload)
        
        self.assertEqual(res.status_code, status.HTTP_200_OK)
        recipe.refresh_from_db()
        for k, v in payload.item():
            self.assertEqual(getattr(recipe, k), v)
        self.assertEqual(recipe.user, self.user)
    
    def text_update_user_returns_error(self):
        """Test changing the recipe user results in an error"""
        new-user = create_user(email='user2@example.com', password='test123')