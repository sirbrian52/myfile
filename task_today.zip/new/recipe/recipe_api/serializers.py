"""serializer for recipe"""

from rest_framework import serializers
from recipe_app.models import Recipe

class RecipeSerializer(serializers.ModelSerializer):
    
    class Meta :
        model = Recipe
        fields = ['id','title','time_minutes','price','link']
        read_only_fields = ['id']

class RecipeDetailSerializer(RecipeSerializer):
    
    class Meta(RecipeSerializer.Meta):
        fields = RecipeSerializer.Meta.Fields + ['description']