import mymodule as mm 

mm.func_in_module()

