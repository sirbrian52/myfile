# x = set()

# x.add(1)
# x.add(2)
# x.add(4)
# x.add(9.1)
# print(x)


# converted = set([1,1,1,1,1,2,2,2,2,2,3,3,3,3])
# print(converted)

# s = 'django'

# print(s[0])
# print(s[-1])
# print(s[:3])


# x =25 

# def func1():
#     x = 50
#     return x



# func1()
# print(x)

#local

# lambda x : x**2

# name = 'this is a global name :'

# def greet():
#     name = "sammy"
    
#     def hello():
#         print("hello"+name)
        
#     hello()

# greet()


# reminding note 

#local function
# x = 50
# def func(x): 
#     print('x is:',x)
#     x = 1000
#     print('local x changed to:',x)
    
    
# func(x)
# print(x)

# global function
# x = 50

# def func(x): 
#     print('x is:',x)

#     x = 1000
#     print('local x changed to:',x)
    
    
# func(x)
# print(x)


### OOP SECtion ###

# class Sample():
#     pass 

# x = Sample()
# print(type(x)) 


# class Dog():
    
    
#     # class object atribut 
#     species = "mamalia"
    
    
#     def __init__(self,breed,name):
#         self.breed = breed
#         self.name = name 

    
# mydog = Dog("Lab","dodi")
# print(mydog.breed)
# print(mydog.name)
# print(mydog.species)



#  Claass

# class Circle():
    
#     p1 = 3.14
    
#     def __init__(self,radius=1):
#         self.radius= radius
    
#     def area(self):
#         return self.radius*self.radius * Circle.p1

#     def set_radius(self,new_r):
#         self.radius = new_r 
        


# myc = Circle(3) 
# myc.set_radius(999)
# print(myc.area())
 

#inheritance
# class Animal():
    
#     def __init__(self):
#         print("animal created")
        
#     def whoami(self):
#         print("animal") 
        
#     def eat(self):
#         print("cating")
        
# mya = Animal()
# mya.whoami()
# mya.eat()


# class Dog(Animal):
    
#     def __init__(self):
#         Animal.__init__(self)
#         print("Dog created")
        
#     def bark(self):
#         print('bark')
    
#     def eat(self):
#         print("dog eating")

# myd = Dog()    
# myd.whoami()
# myd.eat()


#special method 
# class Book():
#     def __init__(self,title,author,pages):
#         self.title = title
#         self.author = author
#         self.pages = pages

#     def __str__(self):
#         return "title {},author: {}, Pages: {}".format(self.title,self.author,self.pages)
    
#     def __len__(self):
#         return self.pages

#     def __del__(self):
#         print("a boook is detroyed:")
        
            

# b = Book("python","jesse",200)
# print(b)



# mylist =[1,2,3]
# print(mylist)







