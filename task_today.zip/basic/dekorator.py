# s = "GLOBAL VARIABLE"


# def func():
#     s= 50
#     print (s)

# func()
# print(s)

# def hello(name="gani"):
#     return "hello"+name

# print(hello())

# mynewgreeet = hello

# print(mynewgreeet())


# def hello(name="gani"):
#     print("the hello() fucntion has been run!")
    
#     def greet():
#         return "this string is inside greet()"
    
#     def welcome():
#         return "this string is inside welcome()"
#     # print(greet())
#     # print(welcome())
#     # print("end of hello")
    
#     if name == "gani":
#         return greet
#     else:
#         return welcome
    
# x = hello()

# print   (x())


# def hello():
#     return "hi brian!"

# def other(func):
#     print("hello")
#     print(func())
    
# other(hello)



def new_decorator(func):
    
    def wrap_func():
        print('code goes here b4 exe')
        func()
        print("func() has benn called")
    
    return wrap_func

@new_decorator
def func_needs_decorator():
    print("this function is in need of a decorator!")
    
    
# func_needs_decorator = new_decorator(func_needs_decorator)

func_needs_decorator()








