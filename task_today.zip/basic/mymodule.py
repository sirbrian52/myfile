def func_in_module():
    print("i am new module")