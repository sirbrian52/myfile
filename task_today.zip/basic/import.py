import re 
# patterns = ['term1', 'terms2']

# text = 'this is a string with term1, not not the other'

# for pattern in patterns:
#     print("i'm searching for :"+pattern)
    
#     if re.search(pattern,text):
#         print("match!")
        
#     else:
#         print('nothing')
        

# split stand for
# split_term = '@'

# email = 'user@gmail.com'

# print(re.split(split_term,email))

def multi_re_find(patterns,phrase):
    
    for pat in patterns:
        print("searching for pattern {}".format(pat))
        print(re.findall(pat,phrase))
        print('\n')

# test_phrase ='sdsd...sddddsddd...dsds...dssssss...sddddd'
test_phrase = 'this is string with numbers 12312 and symbol #hashtag'

test_patterns = [r'\w+']

multi_re_find(test_patterns,test_phrase)

