try :
    f = open('simple.txt','w')
    f.write("test write to simple text")
except IOError:
    print("error: could not find file or read")
    
finally:
    print(" works finely")
    
# else:
#     print("succes!")
#     f.close()
    